<?php
include "../core/php/concentrador.php";
?>
<div class="container">
    <div class="row">
        <h1>Bienvenido al panel administador</h1>
    </div>
</div>
