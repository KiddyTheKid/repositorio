<?php
/**
 * Created by IntelliJ IDEA.
 * User: pedro
 * Date: 19/10/17
 * Time: 21:20
 */
require_once "../php/data/con.php";