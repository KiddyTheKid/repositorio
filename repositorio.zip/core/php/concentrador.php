<?php
//Ayudantes
include "funcs/ayudante.php";
//Base de datos
include "data/Database.php";
//Tablas
include "tablas/Usuarios.php";
include "tablas/Documentos.php";
include "tablas/Autores.php";
include "tablas/TiposDocumentos.php";
include "tablas/Carreras.php";
